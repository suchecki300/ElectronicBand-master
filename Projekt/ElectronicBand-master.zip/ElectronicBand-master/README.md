# ElectronicBand
Realizacja projektu na platformę Android.
