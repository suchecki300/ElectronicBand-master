package pl.wat.wel.projekt.pumo.electronicband;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TheoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theory);
    }
}
